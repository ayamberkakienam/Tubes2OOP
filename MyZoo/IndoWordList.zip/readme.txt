This wordlist is just a text file. 
It contains all the Indonesian words used in the IndoDic online dictionary.

To view it in notepad or another text editor, you may 
need to rename it to "IndoWordList.txt".

For more information on how to install this wordlist for use in word processors, 
see  http://indodic.com/SpellCheckInstall.html

You can search the IndoDic E-Kamus (Dictionary) online at IndoDic.com


